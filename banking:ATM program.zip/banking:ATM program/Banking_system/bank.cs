﻿using System;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
namespace Banking_system{
    class Bank{
       public Bank(){}
       public static Bank b1 = new Bank();
       public static usersession u1 = new usersession();
       public List<usertemplate> users = new List<usertemplate> (){ 
            new usertemplate("Alice","1234","3040",100){Name="Alice",
                Password= "1234",BID="3040",Bal=100},
            new usertemplate("Bob","4321","4002",100){Name="Bob",
                Password= "4321",BID="4002",Bal=100}
        };
       public bool mainsessionactive = true;
       private bool loginsessionactive = true;
       public void main(){
            while(mainsessionactive){
                Console.WriteLine("Welcome to the bank, please select one of " + 
                "the options\n 1) Login\n 2) Register\n 9) Quit \n\n Current" +
                "number of users: {0} ",b1.users.Count);
                switch (Console.ReadLine()) {
                    case "1":
                        Console.Clear();
                        login();
                        mainsessionactive = false;
                        loginsessionactive = true;
                        break;
                    case "2":
                        Console.Clear();
                        newuser();
                        mainsessionactive = false;
                        break;
                    case "9":
                        Console.Clear();
                        mainsessionactive = false;
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Please choose a valid option\n"
                            ,Console.ForegroundColor=ConsoleColor.Red);
                        Console.ForegroundColor=ConsoleColor.White;
                        break;
                }
            }
       }
       public void login(){
            while (loginsessionactive){
                Console.WriteLine("Please enter BankID");
                string bankid = Console.ReadLine();
                Console.WriteLine("Please enter password");
                string password = Console.ReadLine();
	            var query = from u in b1.users
	            where u.BID == bankid & u.Password == password
	            select u.BID + u.Password;
                if ((bankid + password).Equals((string.Join("",query)))){
                        var bid = from u in b1.users
	                    where u.BID == bankid
	                    select u.BID;
                        var bal = from u in b1.users
	                    where u.BID == bankid
	                    select u.Bal;
                        var name = from u in b1.users
	                    where u.BID == bankid
	                    select u.Name;
                        Console.WriteLine("Access granted");
                        Console.Clear();
                        u1.sessionactive = true;
                        u1.session(string.Join("",name),(string.Join("",bid))
                            ,bal.Single());
                        break;
                }else{
                        Console.Clear();                 
                        Console.WriteLine("Username or password wrong, please " +
                            "try again\n",Console.ForegroundColor=ConsoleColor.Red);
                        Console.ForegroundColor=ConsoleColor.White;
                        mainsessionactive = true;
                        loginsessionactive = false;
                        main();
                }
            }
        }
        public void newuser(){
            Random bidgenerator = new Random();
            start:
            Console.Write("Please enter the name of the new user:\n");
            var name = Console.ReadLine();
            foreach (char item in name){
                if (char.IsDigit(item))
                {
                    Console.WriteLine("Invalid name, please re-enter name"
                        ,Console.ForegroundColor=ConsoleColor.Red);
                    Console.ForegroundColor=ConsoleColor.White;
                    goto start;
                }
            }
            Console.Write("Please enter the password of the new user:\n");
            var password = Console.ReadLine();
            var bid = bidgenerator.Next(1000,9999);
            usertemplate newuser = new usertemplate(name,password
                ,string.Join("",bid),0){Name=name,Password=password
                ,BID=string.Join("",bid),Bal=0};
            b1.users.Add(newuser);
            Console.Clear();
            Console.WriteLine("Your new bankID used for login is {0} and your " + 
                "password is {1}\n\n >>Press any key to continue.<<",bid,password);
            Console.ReadLine();
            mainsessionactive = true;
            main();
        }
    }
}