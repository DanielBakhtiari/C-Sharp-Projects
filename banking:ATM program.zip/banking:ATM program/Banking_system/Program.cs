﻿using System;

namespace Banking_system
{
    class Program
    {
        static void Main(string[] args)
        {
            Bank b1 = new Bank();
            b1.main();
        }
    }
}

