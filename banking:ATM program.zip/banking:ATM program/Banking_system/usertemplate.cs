﻿namespace Banking_system{
    class usertemplate{
        public string Name;
        public string Password;
        public string BID;
        public int Bal;
        public usertemplate(string name, string password, string bID, int bal){
            Name = name;
            Password = password;
            BID = bID;
            Bal = bal;
        }
    }
}