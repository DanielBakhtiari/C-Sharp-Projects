﻿using System;
using System.Linq;
using System.Collections.Generic;
namespace Banking_system{
    class usersession{
        public usersession(){}
        public bool sessionactive;
        private bool transfering;
        public void session(string username, string bid, int bal){
            while (sessionactive){
                var currentbal = from u in Bank.b1.users
	            where u.BID == bid
	            select u.Bal; 
                Console.WriteLine("Welcome {0}, please select on of the " +
                    "options\n 1) Transfer money\n 2) Withdraw\n 3) Deposit\n\n 9)" +
                    "Logout\n\nBalance: {1} Kr\n\nBankID: {2}"
                    ,username,currentbal.Single(),bid);
                switch (Console.ReadLine()){
                    case "1":
                        sessionactive = false;
                        transfering = true;
                        Console.Clear();
                        transferto(bid,currentbal.Single());
                        break;
                    case "2":
                        withdraw(bid,currentbal.Single());
                        break;
                    case "3":
                        Deposit(bid,currentbal.Single());
                        break;
                    case "9":
                        Console.Clear();
                        sessionactive = false;
                        Bank.b1.mainsessionactive = true;
                        Bank.b1.main();
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Please choose a valid option\n");
                        break;
                }
            }
        }
        public void transferto(string BID, int bal){       
            while (transfering){
                IEnumerable<string> availablebids =
                    from user in Bank.b1.users
                    select user.BID + ",";
                Console.WriteLine("All available users and their bank ID:\n");
                foreach (var item in Bank.b1.users){
                    Console.WriteLine($"Name: {item.Name}, BID: {item.BID}"); 
                }
                Console.WriteLine("\nPlease enter the bankID you would like to " +
                 "transfer funds to");
                reenterID:
                var bankid = Console.ReadLine();
                foreach (char item in bankid){
                    if (char.IsDigit(item) == false){
                        Console.WriteLine("Invalid input, please re-enter BankID",
                            Console.ForegroundColor=ConsoleColor.Red);
                        Console.ForegroundColor=ConsoleColor.White;
                        goto reenterID;
                    }
                }
                bool BIDexist = false;
                while (BIDexist == false){
                    foreach (var id in availablebids){
                        if ((bankid.Equals(string.Join("",id.Split(","))))){
                            BIDexist = true;
                            break;
                        }
                    }
                    break;
                }
                if (BIDexist == false){
                    Console.Clear();
                    Console.WriteLine("BankID not valid \n",
                        Console.ForegroundColor=ConsoleColor.Red);
                    Console.ForegroundColor=ConsoleColor.White;
                    sessionactive = true;
                    transfering = false;
                    break;
                }
                Console.WriteLine("Please enter the amount of money");
                reenteramount:
                var amount = Console.ReadLine();
                foreach (char item in amount){
                    if (char.IsDigit(item) == false){
                        Console.WriteLine("Invalid input, please re-enter amount",
                            Console.ForegroundColor=ConsoleColor.Red);
                        Console.ForegroundColor=ConsoleColor.White;
                        goto reenteramount;
                    }
                }
                if (bal < Int32.Parse(amount)){
                    Console.Clear();
                    Console.WriteLine("Insufficient funds, transaction failed\n",
                        Console.ForegroundColor=ConsoleColor.Red);
                    Console.ForegroundColor=ConsoleColor.White;
                    sessionactive = true;
                    transfering = false;
                    break;
                }
                var query = from u in Bank.b1.users
	            where u.BID == bankid
	            select u.Name; 
                Console.Clear();   
                Console.WriteLine("You are trying to transfer to {0} , your new " + 
                    "balance would be {1} kr, proceed? (y/n)",string.Join("",query)
                    ,bal -= Int32.Parse(amount));
                switch (Console.ReadLine()){
                    case "y":
                        Bank.b1.users.Where(u=> u.BID == BID).ToList()
                            .ForEach(i => i.Bal -= Int32.Parse(amount));
                        Bank.b1.users.Where(u=> u.BID == bankid).ToList()
                            .ForEach(i => i.Bal += Int32.Parse(amount));
                        sessionactive = true;
                        transfering = false;
                        Console.Clear();
                        Console.WriteLine("Transfer successful\n",
                            Console.ForegroundColor=ConsoleColor.Green);
                        Console.ForegroundColor=ConsoleColor.White;
                        break;
                    case "n":
                        Console.Clear();
                        Console.WriteLine("Transfer cancelled\n",
                            Console.ForegroundColor=ConsoleColor.Yellow);
                        Console.ForegroundColor=ConsoleColor.White;
                        sessionactive = true;
                        transfering = false;
                        break;
                    default:
                        Console.Clear();
                        Console.WriteLine("Please choose a valid option\n");
                        break;
                }
            }
        }
        public void withdraw(string BID, int bal){       
            Console.WriteLine("Please enter the amount of money you would like " + 
                "to withdraw");
            reenteramount:
            var amount = Console.ReadLine();
            foreach (char item in amount){
                if (char.IsDigit(item) == false){
                    Console.WriteLine("Invalid input, please re-enter amount",
                        Console.ForegroundColor=ConsoleColor.Red);
                    Console.ForegroundColor=ConsoleColor.White;
                    goto reenteramount;
                }
            }
            if (bal < Int32.Parse(amount)){
                Console.Clear();
                Console.WriteLine("Insufficient funds, withdrawal failed\n"
                    ,Console.ForegroundColor=ConsoleColor.Red);
                Console.ForegroundColor=ConsoleColor.White;
            }else{
                Console.Clear();
                Console.WriteLine("Withdrawal successful\n"
                    ,Console.ForegroundColor=ConsoleColor.Green);
                Console.ForegroundColor=ConsoleColor.White;
                Bank.b1.users.Where(u=> u.BID == BID).ToList()
                    .ForEach(i => i.Bal -= Int32.Parse(amount));
            }
        }
        public void Deposit(string BID, int bal)
        {       
            Console.WriteLine("Please enter the amount of money you would like " +
            "to deposit");
            reenteramount:
            var amount = Console.ReadLine();
            foreach (char item in amount){
                if (char.IsDigit(item) == false){
                    Console.WriteLine("Invalid input, please re-enter amount",
                        Console.ForegroundColor=ConsoleColor.Red);
                    Console.ForegroundColor=ConsoleColor.White;
                    goto reenteramount;
                }
            }
            Bank.b1.users.Where(u=> u.BID == BID).ToList().ForEach
                (i => i.Bal += Int32.Parse(amount));
            Console.Clear();
            Console.WriteLine("Deposit successful\n",
                Console.ForegroundColor=ConsoleColor.Green);
            Console.ForegroundColor=ConsoleColor.White;
        }
    }
}