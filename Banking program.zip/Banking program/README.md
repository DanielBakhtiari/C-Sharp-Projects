Default users for login:

Name="Alice",Password= "1234",BID="3040",Bal=100

Name="Bob",Password= "4321",BID="4002",Bal=100}